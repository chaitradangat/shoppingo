﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WebPageSave
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n"+"input folder:");
            var inputfolder = Console.ReadLine();

            Console.WriteLine("\n"+"output folder:");
            var outputfolder = Console.ReadLine();

            HtmlHelper h = new HtmlHelper();

            var files = Directory.GetFiles(inputfolder, "*.txt", SearchOption.AllDirectories);

            var totalfiles = files.Length;
            var fileidx = 0;

            foreach (var file in files)
            {
                ++fileidx;

                var urls = new HashSet<string>(File.ReadAllLines(file));

                var totalurls = urls.Count;
                var urlidx = 0;

                Console.WriteLine("checking existing files...");

                foreach (var url in urls)
                {
                    ++urlidx;

                    var outputFile = string.Format(@"{0}\{1}_{2}.html", outputfolder, Path.GetFileNameWithoutExtension(file), urlidx);

                    if (File.Exists(outputFile))
                    {
                        if (File.ReadAllText(outputFile).ToLower().Contains("utf-8"))
                        {
                            Console.WriteLine("skipping file...");
                            continue;
                        }
                    }
                    else
                    {
                        File.Delete(outputFile);
                    }
                }

                Console.WriteLine("checking existing files completed..");


                urlidx = 0;

                foreach (var url in urls)
                {
                    ++urlidx;

                    var outputFile = string.Format(@"{0}\{1}_{2}.html", outputfolder, Path.GetFileNameWithoutExtension(file), urlidx);

                    if (File.Exists(outputFile))
                    {
                        continue;
                    }

                    if (urlidx % 10 == 0)
                    {
                        Console.WriteLine("[Parsing] file: {0}\\{1} url: {2}\\{3}", fileidx, totalfiles, urlidx, totalurls);
                    }

                    var rawHtmlText = "";
                    Encoding enc = Encoding.UTF8;

                    try
                    {
                        h.DownloadPage(url, ref rawHtmlText, enc);

                        h.DetectEncoding(rawHtmlText, ref enc);

                        h.DownloadPage(url, ref rawHtmlText, enc);

                        if (!string.IsNullOrEmpty(rawHtmlText))
                        {
                            File.WriteAllText( string.Format(@"{0}\{1}_{2}.html",outputfolder,Path.GetFileNameWithoutExtension(file),urlidx), rawHtmlText, enc);
                        }
                    }
                    catch (Exception)
                    {

                    }
                }
            }

            Console.ReadLine();
            Console.WriteLine("Fin!");
        }
    }
}


