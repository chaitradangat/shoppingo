﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace WebPageSave
{
    class HtmlHelper
    {
        private Regex rgxEncoding { get; set; }

        private WebClient wc { get; set; }


        public HtmlHelper()
        {
            rgxEncoding = new Regex(@"charset\s?\=\s?['|""]?(?<data>.*?)['|""]", RegexOptions.Compiled);
            wc = new WebClient();
        }

        public void DetectEncoding(string rawHtmlText,ref Encoding enc)
        {
            enc = Encoding.UTF8;

            string [] htmllines =  rawHtmlText.Split('\n');

            foreach (var htmlline in htmllines)
            {
                if (rgxEncoding.IsMatch(htmlline))
                {
                    try
                    {
                        enc = Encoding.GetEncoding(rgxEncoding.Match(htmlline).Groups["data"].Value);
                        break;
                    }
                    catch (Exception)
                    {

                    }
                }
            }
        }

        public void DownloadPage(string url,ref string rawHtmlText,Encoding enc)
        {
            try
            {
                wc.Encoding = enc;
                rawHtmlText = wc.DownloadString(url);
            }
            catch (Exception)
            {

            }
        }
    }
}
